/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.google;
/**
 *
 * @author mona_
 */
public class GoogleClass {
    
    public float ConvertTemptoCelsius(float temp){
        return (temp-32)*5/9;
    }
    
    public float ConvertTemptoFahrenhit(float temp){
        return (((temp*9)/5)+32);
    }
}
