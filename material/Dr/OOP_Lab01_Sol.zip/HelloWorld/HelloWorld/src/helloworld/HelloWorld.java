/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helloworld;
import com.google.GoogleClass;
import java.util.Scanner;

public class HelloWorld {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /*
		 *Quadratic Equation: 3X2 -8X + 4 
		 */
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter value of X:");
		double x = scanner.nextDouble();
		Double result = (3*x*x)-(8*x)+4;
		System.out.println("The result of the Equation 3X2 -8X + 4 is: "+result);
		
		
		/*
		 * adding Two Numbers Read From User
		 */
		 scanner = new Scanner(System.in);
		System.out.print("Enter First Number: ");
		int firstNumber = scanner.nextInt();
		System.out.print("Enter Second Number: ");
		int secondNumber = scanner.nextInt();
		System.out.printf("The Sum is: %d",firstNumber+secondNumber);
		
		 /*
		  *show the following message 
		 X Said: "I have 1500000 $" 
		 Y Said: "ok Mr\X,I have 1000.525435 $"
		 */
		
		//int x=1500000;
		double y=1000.525435;
		String mrX="X";
		char currency='$';

		System.out.printf(" %s Said: \"I have %f %c\" \n",mrX,x,currency);
		System.out.printf(" Y Saind: \"ok Mr\\%s,I have %f %c\" ",mrX,y,currency);
		
        // TODO code application logic here
                /*
		 * Converting Temperature from Celsius to Fahrenheit and
                 * vice versa
		 */
                GoogleClass obj=new GoogleClass();
                Scanner scanner1 = new Scanner(System.in);
                System.out.print("Enter Temperature: ");
                float xx = scanner1.nextFloat();
                System.out.print("Convert Temperature to (C for Celsius & F for Fahrenheit): ");
                String tempType = scanner1.next().toLowerCase();
                float convertedTemp;
                if(tempType.equals("c")){
                    //convertedTemp = ConvertTemptoCelsius(xx);
                    convertedTemp = obj.ConvertTemptoCelsius(xx);
                    System.out.println(convertedTemp);
                }
                else if (tempType.equals("f")){
                    //convertedTemp=ConvertTemptoFahrenhit(xx);
                    convertedTemp=obj.ConvertTemptoFahrenhit(xx);
                    System.out.println(convertedTemp);
                }
        
        
    }
    
    public static float ConvertTemptoCelsius(float temp){
        return (temp-32)*5/9;
    }
    
    public static float ConvertTemptoFahrenhit(float temp){
        return (((temp*9)/5)+32);
    }

    
}
